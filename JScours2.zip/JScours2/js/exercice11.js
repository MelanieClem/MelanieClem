// lire une lettre
// w = avancer
// a = gauche
// s = reculer
// d = droite
// si autre chose erreur

var lettre

lettre= prompt("demander une lettre")

if( lettre.toUpperCase() === "w"){
    reponse = "avancer"
}

else if ( lettre.toUpperCase() === "a"){
    reponse = "gauche"
}

else if ( lettre.toUpperCase() === "s"){
    reponse = "reculer"
}

else if ( lettre.toUpperCase() === "d"){
    reponse = "droite"
}

else {
    reponse = "erreur"
}

console.log (reponse)