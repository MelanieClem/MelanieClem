//demandez 2 nombre à l'usager

var premierNombre
var deuxiemeNombre

premierNombre = prompt("Indiquez un premier nombre");
deuxiemeNombre = prompt("Indiquez un deuxième nombre");

if(premierNombre && deuxiemeNombre > 9){
    console.log(" Bonjour ");
}

else{
    console.log ("Bonsoir")
}
