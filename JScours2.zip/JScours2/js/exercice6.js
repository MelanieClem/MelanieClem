var note


note = prompt("Indiquez votre note ici");
note = parseFloat(note)

if(note >= 90) {
    console.log(" Votre note est : " + "A");
    }
    else if (note >=80){
        console.log("Votre note est : " + "B");
    }
        else if (note >= 70){
            console.log ("Votre note est : " + "C");
        }
            else if (note >= 60){
                console.log ("Votre note est : " + "D")
            }

else{
    console.log (" Votre note est : " + "E")
}