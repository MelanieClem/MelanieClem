var nombreDuMois

nombreDuMois = prompt("Indiquer un mois en chiffre");
nombreDuMois = parseInt(nombreDuMois);

if ( nombreDuMois === 1){
    console.log ("Janiver");
}
else if ( nombreDuMois === 2 ){
    console.log ("Février");
}
else if ( nombreDuMois === 3 ){
    console.log ("Mars");
}
else if ( nombreDuMois === 4 ){
    console.log ("Avril");
}
else if ( nombreDuMois === 5 ){
    console.log ("Mai");
}
else if ( nombreDuMois === 6 ){
    console.log ("Juin");
}
else if ( nombreDuMois === 7 ){
    console.log ("Juillet");
}
else if ( nombreDuMois === 8 ){
    console.log ("Août");
}
else if ( nombreDuMois === 9 ){
    console.log ("septembre");
}
else if ( nombreDuMois === 10 ){
    console.log ("Octobre");
}
else if ( nombreDuMois === 11 ){
    console.log ("Novembre");
}
else if ( nombreDuMois === 12 ){
    console.log ("Décembre");
}
else {
    console.log("Mois invalide");
}

